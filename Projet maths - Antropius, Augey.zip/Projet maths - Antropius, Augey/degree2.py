__author__ = "ANTROPIUS Simon, AUGEY Louis"
__date__ = "2024-05-22"

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider

##### Definition of the equation ##############################################

# Euler method works for 1 degree ODE only. If we have to solve equations
# with a degree > 1, we need to decouple them. Here with a degree 2:

# y''(x) = f(x, y, y')
# -> with z(x) = y'(x):
# y'(x) = z(x) and
# z'(x) = f(x, y, z)
# We solve each one with Euler's method

def f(x, y, z):
    """
    Right side of the ODE y''(x) = -a(x)*y'(x) + b(x)y(x) + c(x).
    Define the equation here.

    :param x: The value of x.
    :param y: The value of y(x).
    :param z: The value of y'(x).
    :return: The value of -a(x)*y'(x) + b(x)y(x) + c(x).
    """
    g = 9.81
    # Replace the return by:
    # -(g/l)*np.sin(y) - 0.2*z for an example of damped oscillator
    # -(g/l)*np.sin(y) + 0.2*np.sin(0.15*x) for an example of forced oscillator
    return -(g/l)*np.sin(y)

# Initial conditions
x0 = 0 # Initial value of x
y0 = np.pi/200 # Initial value of y (i.e. f(x0))
z0 = 0 # Initial value of y' (i.e. f'(x0))
l = 0.5 # Length of the rope

##### Euler's solution ########################################################

def euler_second_order(f, x, y0, z0):
    """
    Approximates the solution of the second-order ODE y'' = f(x, y, y') using
    Euler's method.

    :param f: The function f(x, y, y') representing the right-hand side of
    the second-order ODE.
    :param x: The array containing the values of x.
    :param y0: The initial value of y.
    :param z0: The initial value of dy/dx.
    :return: An array containing the approximation of y.
    """
    n = len(x)  # Number of steps
    h = x[1] - x[0]  # Step size
    y = np.zeros(n)
    z = np.zeros(n)
    y[0] = y0
    z[0] = z0
    for i in range(1, n):
        z[i] = z[i-1] + h * f(x[i-1], y[i-1], z[i-1])
        y[i] = y[i-1] + h * z[i]
    return y

##### Runge kutta #############################################################

def runge_kutta_second_order(f, x, y0, z0):
    """
    Approximates the solution of the second-order ODE y'' = f(x, y, y') using
    the second-order Runge-Kutta method.

    :param f: The function f(x, y, y') representing the right-hand side of
    the second-order ODE.
    :param x: The array containing the values of x.
    :param y0: The initial value of y.
    :param z0: The initial value of dy/dx.
    :return: An array containing the approximation of y.
    """
    n = len(x)  # Number of steps
    h = x[1] - x[0]  # Step size
    y = np.zeros(n)
    z = np.zeros(n)
    y[0] = y0
    z[0] = z0
    for i in range(1, n):
        k1 = f(x[i-1], y[i-1], z[i-1])
        k2 = f(x[i-1] + h/2, y[i-1] + (h/2)*z[i-1], z[i-1] + (h/2)*k1)
        k3 = f(x[i-1] + h/2, y[i-1] + (h/2)*z[i-1] + (h*h/4)*k1, z[i-1] +
               (h/2)*k2)
        k4 = f(x[i-1] + h, y[i-1] + h*z[i-1] + (h*h/2)*k2, z[i-1] + h*k3)

        z[i] = z[i-1] + (h/6)*(k1+2*k2+2*k3+k4)
        y[i] = y[i-1] + h*z[i-1] + (h*h/6)*(k1+k2+k3)
    return y

##### Exact solution ##########################################################

def analytical_solution(x):
    """
    Solution of the ODE y''(x) = -a(x)*y'(x) + b(x)y(x) + c(x).
    Define the solution to the equation here.

    :param x: The array containing the values of x.
    :return: An array containing the exact values of y.
    """
    g = 9.81
    return y0*np.cos(np.sqrt(g/l)*(x-x0)) + z0*np.sqrt(l/g)*np.sin(
        np.sqrt(g/l)*(x-x0))

##### Error ###################################################################

def error_euler_runge_kutta(f_analytical, f_euler, f_runge_kutta):
    """
    Computes the error between euler and the exact solution and runge-kutta
    and the exact solution.

    :param f_analytical: An array containing the exact values of y.
    :param f_euler: An array containing approximated values of y with euler.
    :param f_runge_kutta: An array containing approximated values of y with
    runge-kutta.
    :return: 2 arrays containing the the error between euler and the exact
    solution and runge-kutta and the exact solution.
    """
    return np.abs(f_euler - f_analytical), np.abs(f_runge_kutta - f_analytical)

##### Computations ############################################################

# Interval
a = x0 # Beginning of the interval
b = 10 # End of the interval
n = 10000  # Number of steps

x = np.linspace(a, b, n)

y_analytical = analytical_solution(x)
y_euler = euler_second_order(f, x, y0, z0)
y_runge_kutta = runge_kutta_second_order(f, x, y0, z0)

y_error_euler, y_error_runge_kutta = error_euler_runge_kutta(y_analytical,
                                                             y_euler,
                                                             y_runge_kutta)

##### Figure ##################################################################

fig, ax = plt.subplots(2, figsize=(15, 8))
plt.subplots_adjust(bottom=0.25, hspace=0.5)

ax[0].plot(x, y_analytical, label='Exact solution')
ax[0].plot(x, y_euler, label='Approximated solution (Euler)')
ax[0].plot(x, y_runge_kutta, label='Approximated solution (Runge-Kutta)')
ax[0].set_xlabel('x')
ax[0].set_ylabel('y')
ax[0].set_title(f"Approximated and exact solution of d^2y/dx^2 = -(g/l)*sin("
                f"y) using Euler\'s Method and Runge-Kutta\'s Method")
ax[0].legend()
ax[0].grid(True)

ax[1].plot(x, y_error_euler, label='Euler/Analytical')
ax[1].plot(x, y_error_runge_kutta, label='Runge-Kutta/Analytical')
ax[1].set_xlabel('x')
ax[1].set_ylabel('y')
ax[1].set_title(
    "Error between Euler/Runge-Kutta methods and the analytical solution")
ax[1].legend()

##### Sliders #################################################################

ax_slider_z0 = plt.axes([0.25, 0.05, 0.65, 0.03])
ax_slider_y0 = plt.axes([0.25, 0.1, 0.65, 0.03])
ax_slider_n = plt.axes([0.25, 0.15, 0.65, 0.03])

s_y0 = Slider(ax_slider_y0, 'y0', -np.pi, np.pi, valinit=y0, valstep=0.01)
s_z0 = Slider(ax_slider_z0, 'y0\'', -10, 10, valinit=z0, valstep=0.01)
s_n = Slider(ax_slider_n, 'Nb of steps', 5, 10000, valinit=n, valstep=1)

def update(val):
    """
    Updates the canvas when a slider if touched.
    Computes the error between euler and the exact solution and runge-kutta
    and the exact solution.
    """
    global y0, z0, n
    y0 = s_y0.val
    z0 = s_z0.val
    n = s_n.val

    x = np.linspace(a, b, n)
    y_analytical = analytical_solution(x)
    y_euler = euler_second_order(f, x, y0, z0)
    y_runge_kutta = runge_kutta_second_order(f, x, y0, z0)

    y_error_euler, y_error_runge_kutta = error_euler_runge_kutta(y_analytical,
                                                                 y_euler,
                                                                 y_runge_kutta)

    ax[0].clear()
    ax[0].plot(x, y_analytical, label='Exact solution')
    ax[0].plot(x, y_euler, label='Approximated solution (Euler)')
    ax[0].plot(x, y_runge_kutta, label='Approximated solution (Runge-Kutta)')
    ax[0].set_xlabel('x')
    ax[0].set_ylabel('y')
    ax[0].set_title(f"Approximated and exact solution of d^2y/dx^2 = -("
                    f"g/l)*sin(y) using Euler\'s Method and Runge-Kutta\'s "
                    f"Method")
    ax[0].legend()
    ax[0].grid(True)

    ax[1].clear()
    ax[1].plot(x, y_error_euler, label='Euler/Analytical')
    ax[1].plot(x, y_error_runge_kutta, label='Runge-Kutta/Analytical')
    ax[1].set_xlabel('x')
    ax[1].set_ylabel('y')
    ax[1].set_title(
        "Error between Euler/Runge-Kutta methods and the analytical solution")
    ax[1].legend()

    fig.canvas.draw()

s_y0.on_changed(update)
s_z0.on_changed(update)
s_n.on_changed(update)

##### Run #####################################################################

plt.show()