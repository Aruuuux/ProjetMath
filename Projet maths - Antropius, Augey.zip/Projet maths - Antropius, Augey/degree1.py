__author__ = "ANTROPIUS Simon, AUGEY Louis"
__date__ = "2024-05-13"

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider

##### Definition of the equation ##############################################

def f(x, y):
    """
    Right side of the ODE y'(x) = -a(x)*y(x) + b(x).
    Define the equation here. Be careful to also change the exact solution
    and the potential sliders to change the value of a coeff. if you modify
    the equation.

    :param x: The value of x.
    :param y: The value of y(x).
    :return: The value of -a(x)*y(x) + b(x).
    """
    return -k * y

# Initial conditions
x0 = 4  # Initial value of x
y0 = 5  # Initial value of y (i.e. f(x0))
k = 0.3  # Initial value of k, used in the equation

##### Euler's solution ########################################################

def euler_method(f, x, y0):
    """
    Approximates the solution of the ODE y' = f(x, y) using Euler's method.

    :param f: The function f(x, y) representing the right-hand side of the ODE.
    :param x: The array containing the values of x.
    :param y0: The initial value of y.
    :return: An array containing the approximation of y.
    """
    n = len(x)  # Number of steps
    h = x[1] - x[0]  # Step size
    y = np.zeros(n)
    y[0] = y0
    for i in range(1, n):
        y[i] = y[i - 1] + h * f(x[i - 1], y[i - 1])
    return y

##### Runge-Kutta's solution ##################################################

def runge_kutta_method(f, x, y0):
    """
    Approximates the solution of the ODE y' = f(x, y) using Runge-Kutta's
    method.

    :param f: The function f(x, y) representing the right-hand side of the ODE.
    :param x: The array containing the values of x.
    :param y0: The initial value of y.
    :return: An array containing the approximation of y.
    """
    n = len(x)  # Number of steps
    h = x[1] - x[0]  # Step size
    y = np.zeros(n)
    y[0] = y0
    for i in range(1, n):
        k1 = h * f(x[i - 1], y[i - 1])
        k2 = h * f(x[i - 1], y[i - 1] + k1 / 2)
        k3 = h * f(x[i - 1], y[i - 1] + k2 / 2)
        k4 = h * f(x[i - 1], y[i - 1] + k3)
        y[i] = y[i - 1] + (1 / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
    return y

##### Exact solution ##########################################################

def analytical_solution(x):
    """
    Solution of the ODE y'(x) = -a(x)*y(x) + b(x).
    Define the solution to the equation here.

    :param x: The array containing the values of x.
    :param initial_coefficient: Initial value of the coefficient.
    :return: An array containing the exact values of y.
    """
    return y0 * np.exp(-k * (x-x0))

##### Error ###################################################################

def error_euler_runge_kutta(f_analytical, f_euler, f_runge_kutta):
    """
    Computes the error between euler and the exact solution and runge-kutta
    and the exact solution.

    :param f_analytical: An array containing the exact values of y.
    :param f_euler: An array containing approximated values of y with euler.
    :param f_runge_kutta: An array containing approximated values of y with
    runge-kutta.
    :return: 2 arrays containing the the error between euler and the exact
    solution and runge-kutta and the exact solution.
    """
    return np.abs(f_euler - f_analytical), np.abs(f_runge_kutta - f_analytical)

##### Computations ############################################################

# Interval
a = x0  # Beginning of the interval
b = 30  # End of the interval
n = 1000  # Number of steps

x = np.linspace(a, b, n)

y_analytical = analytical_solution(x)
y_euler = euler_method(f, x, y0)
y_runge_kutta = runge_kutta_method(f, x, y0)

y_error_euler, y_error_runge_kutta = error_euler_runge_kutta(y_analytical,
                                                             y_euler,
                                                             y_runge_kutta)

##### Figure ##################################################################

fig, ax = plt.subplots(2, figsize=(15, 8))
plt.subplots_adjust(bottom=0.25, hspace=0.5)

ax[0].plot(x, y_analytical, label='Exact solution')
ax[0].plot(x, y_euler, label='Approximated solution (Euler)')
ax[0].plot(x, y_runge_kutta, label='Approximated solution (Runge-Kutta)')
ax[0].set_xlabel('x')
ax[0].set_ylabel('y')
ax[0].set_title(
    f"Approximated and exact solution of dy/dx = -{k}*y using Euler's and "
    f"Runge-Kutta's methods")
ax[0].legend()
ax[0].grid(True)

ax[1].plot(x, y_error_euler, label='Euler/Analytical')
ax[1].plot(x, y_error_runge_kutta, label='Runge-Kutta/Analytical')
ax[1].set_xlabel('x')
ax[1].set_ylabel('y')
ax[1].set_title(
    "Error between Euler/Runge-Kutta methods and the analytical solution")
ax[1].legend()

##### Sliders #################################################################

ax_slider_y0 = plt.axes([0.25, 0.05, 0.65, 0.03])
ax_slider_n = plt.axes([0.25, 0.1, 0.65, 0.03])
ax_slider_k = plt.axes([0.25, 0.15, 0.65, 0.03])

s_y0 = Slider(ax_slider_y0, 'y0', -10, 10, valinit=y0, valstep=1)
s_n = Slider(ax_slider_n, 'Nb of steps', 5, 1000, valinit=n, valstep=1)
s_k = Slider(ax_slider_k, 'k', 0.1, 10, valinit=k, valstep=0.1)

def update(val):
    """
    Updates the canvas when a slider if touched.
    Computes the error between euler and the exact solution and runge-kutta
    and the exact solution.
    """
    global y0, n, k
    y0 = s_y0.val
    n = s_n.val
    k = s_k.val

    x = np.linspace(a, b, n)
    y_analytical = analytical_solution(x)
    y_euler = euler_method(f, x, y0)
    y_runge_kutta = runge_kutta_method(f, x, y0)

    y_error_euler, y_error_runge_kutta = error_euler_runge_kutta(y_analytical,
                                                                 y_euler,
                                                                 y_runge_kutta)

    ax[0].clear()
    ax[0].plot(x, y_analytical, label='Exact solution')
    ax[0].plot(x, y_euler, label='Approximated solution (Euler)')
    ax[0].plot(x, y_runge_kutta, label='Approximated solution (Runge-Kutta)')
    ax[0].set_xlabel('x')
    ax[0].set_ylabel('y')
    ax[0].set_title(
        f"Approximated and exact solution of dy/dx = -{k}*y using Euler's "
        f"and Runge-Kutta's methods")
    ax[0].legend()
    ax[0].grid(True)

    ax[1].clear()
    ax[1].plot(x, y_error_euler, label='Euler/Analytical')
    ax[1].plot(x, y_error_runge_kutta, label='Runge-Kutta/Analytical')
    ax[1].set_xlabel('x')
    ax[1].set_ylabel('y')
    ax[1].set_title(
        "Error between Euler/Runge-Kutta methods and the analytical solution")
    ax[1].legend()

    fig.canvas.draw()

s_y0.on_changed(update)
s_n.on_changed(update)
s_k.on_changed(update)

##### Run #####################################################################

plt.show()
